#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CNT 1000

struct node {
    float num;
    char op;
};

struct node datas[CNT];  //��׺����ʽջ
int data_top = -1;       //ջ������

char ops[CNT];          //������ջ
int op_top = -1;        //ջ������

char nums[100];         //�����ַ���
int num_top = -1;       //ջ������
//������ջ
void push_num() {
    if (num_top > -1) {
        datas[++data_top].num = atof(nums);
        datas[data_top].op = 0;
        num_top = -1;
        memset(nums, 0, sizeof(nums));
    }
}
//��׺ת��׺
void mtoe(const char* str) {
    char* tmp;
    tmp = (char*)str;
    while (*tmp != '\0') {
        char ch = *tmp;
        ++tmp;
        if (ch == ' ') continue;

        if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '(') {
            push_num();
            if (op_top > -1) {
                char op = ops[op_top];
                if ((op == '*' || op == '/') && (ch == '+' || ch == '-')) {// ��/�������ڼ�/��
                    datas[++data_top].op = op;
                    --op_top;
                }
            }
            ops[++op_top] = ch;
        }
        else if (ch == ')') {
            push_num();
            while (ops[op_top] != '(') {
                datas[++data_top].op = ops[op_top];
                --op_top;
            }
            --op_top;
        }
        else {
            nums[++num_top] = ch;
        }
    }// end of while *tmp 
    push_num();//����������ջ
    while (op_top > -1) {//���Ĳ�������ջ
        datas[++data_top].op = ops[op_top];
        --op_top;
    }
}
//����ֵ
float calculating() {
    if (data_top < 0) return 0;
    float stack[CNT] = { 0 };
    int top = -1;
    int i = 0;
    while (i <= data_top) {
        char op = datas[i].op;
        if (op == 0) {
            stack[++top] = datas[i].num;
        }
        else {
            float a = stack[top - 1];
            float b = stack[top];
            --top;
            float c = 0;
            if (op == '+') c = a + b;
            else if (op == '-') c = a - b;
            else if (op == '*') c = a * b;
            else if (op == '/') c = a / b;
            stack[top] = c;
            if (c < 0)
            {
                return -1;
            }
        }
        ++i;
    }
     return stack[top];
}